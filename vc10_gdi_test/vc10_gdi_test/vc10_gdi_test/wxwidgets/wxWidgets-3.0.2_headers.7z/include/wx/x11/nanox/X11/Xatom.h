
/*
 * Xlib compatibility
 */

/* Nothing yet */
