/*
 * Xlib compatibility
 */

/* Nothing yet */
