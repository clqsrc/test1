/////////////////////////////////////////////////////////////////////////////
// Name:        wx/sashwin.h
// Purpose:     Base header for wxSashWindow
// Author:      Julian Smart
// Modified by:
// Created:
// Copyright:   (c) Julian Smart
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_SASHWIN_H_BASE_
#define _WX_SASHWIN_H_BASE_

#include "wx/generic/sashwin.h"

#endif
    // _WX_SASHWIN_H_BASE_
